#!/bin/bash
#SBATCH -p amd_256 -J a2_c_1
#SBATCH -N 1
#SBATCH -n 64
#source /public1/soft/modules/module.sh 
module purge
module load gcc/9.3.0-kd
module load mpi/intel/19.3.0

source /public1/home/scb5073/tangbo/soft/new/cp2k-9.1/tools/toolchain/install/setup
export PATH=/public1/home/scb5073/tangbo/soft/new/cp2k-9.1/exe/local:$PATH
export LD_LIBRARY_PATH=/public1/home/scb5073/tangbo/soft/new/cp2k-9.1/lib/local/psmp:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/public1/home/scb5073/tangbo/soft/new/cp2k-9.1/lib/local/pdbg:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/public1/home/scb5073/tangbo/soft/new/cp2k-9.1/lib/local/ssmp:$LD_LIBRARY_PATH
mpirun -np 64 cp2k.popt -i md.inp -o md.log
